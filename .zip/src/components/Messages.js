import { useEffect, useState, useRef } from "react";
import { supabase } from '../supabaseClient';
import { FaEnvelope, FaPaperPlane } from 'react-icons/fa';
import Sidebar from './Sidebar';
import '../global.css';
import '../sidebar.css';
import '../main.css';
import '../singlemessage.css';

const Messages = ({ user, onLogout, setView, otherUserId }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const intervalRef = useRef(null);

  useEffect(() => {
    console.log('Messages.js - otherUserId received:', otherUserId); // Debug log

    if (!otherUserId) {
      console.error('No otherUserId provided!');
      setError('No user selected for messaging.');
      setLoading(false);
      return;
    }

    const fetchMessagesAndProfile = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch messages
        const { data: messagesData, error: messagesError } = await supabase
          .from('career_messages')
          .select('*')
          .or(`and(sender_id.eq.${user.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${user.id})`)
          .order('created_at', { ascending: true })
          .limit(100);

        if (messagesError) throw new Error(`Messages fetch error: ${messagesError.message}`);
        console.log('Fetched messages:', messagesData); // Debug log
        setMessages(messagesData || []);

        // Fetch other user's profile
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('email, username')
          .eq('id', otherUserId)
          .single();

        if (profileError) throw new Error(`Profile fetch error: ${profileError.message}`);
        console.log('Fetched profile:', profileData); // Debug log
        setProfile(profileData || { email: 'Unknown User' });
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.message);
        setMessages([]);
        setProfile({ email: 'User Not Found' });
      } finally {
        setLoading(false);
      }
    };

    fetchMessagesAndProfile();
    intervalRef.current = setInterval(fetchMessagesAndProfile, 10000);

    return () => clearInterval(intervalRef.current);
  }, [user.id, otherUserId]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !otherUserId) {
      console.error('Message empty or no receiver specified!');
      return;
    }

    try {
      const { error } = await supabase
        .from('career_messages')
        .insert({
          sender_id: user.id,
          receiver_id: otherUserId,
          content: newMessage,
          created_at: new Date().toISOString(),
        });

      if (error) throw error;

      setMessages(prev => [...prev, {
        sender_id: user.id,
        receiver_id: otherUserId,
        content: newMessage,
        created_at: new Date().toISOString(),
      }]);
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      setError('Failed to send message.');
    }
  };

  if (loading) return <div>Loading conversation...</div>;

  if (error) {
    return (
      <div className="flex">
        <Sidebar currentView="messages" setView={setView} onLogout={onLogout} />
        <div className="main-content">
          <header className="header">
            <h2>Messages</h2>
          </header>
          <p>Error: {error}</p>
          <button onClick={() => setView({ screen: 'people' })}>
            Back to People
          </button>
        </div>
      </div>
    );
  }

  if (!otherUserId) {
    return (
      <div className="flex">
        <Sidebar currentView="messages" setView={setView} onLogout={onLogout} />
        <div className="main-content">
          <header className="header">
            <h2>Select a User to Message</h2>
          </header>
          <p>Please go to People and select a user to start a conversation.</p>
          <button onClick={() => setView({ screen: 'people' })}>
            Go to People
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex">
      <Sidebar currentView="messages" setView={setView} onLogout={onLogout} />

      <div className="main-content">
        <header className="header">
          <h2>Chatting With {profile?.username || profile?.email}</h2>
        </header>

        <div className="messages-container">
          <div className="messages-list">
            {messages.length === 0 ? (
              <p>No messages yet. Start the conversation!</p>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id || `${message.created_at}-${message.sender_id}`}
                  className={`message-card-single ${message.sender_id === user.id ? 'sent' : 'received'}`}
                >
                  <div className="message-header">
                    <FaEnvelope className="message-icon" />
                    <span className="message-sender-single">{message.content}</span>
                    <span className="message-time">
                      {new Date(message.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <form className="message-form" onSubmit={handleSendMessage}>
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
          />
          <button type="submit">
            <FaPaperPlane /> Send
          </button>
        </form>
      </div>
    </div>
  );
};

export default Messages;