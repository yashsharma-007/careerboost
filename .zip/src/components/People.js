import { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { FaUser, FaSignOutAlt, FaTrophy, FaBook, FaBriefcase, FaFileAlt, FaTasks, FaComments, FaUsers, FaHome, FaSearch, FaUserPlus, FaEnvelope, FaIdBadge, FaTools, FaInfoCircle, FaUserCheck, FaHourglassHalf, FaFilter, FaSort, FaCheck, FaTimes } from 'react-icons/fa';
import Sidebar from './Sidebar';
import '../global.css';
import '../sidebar.css';
import '../main.css';
import '../people.css';

const People = ({ user, onLogout, setView }) => {
  const [people, setPeople] = useState([]);
  const [outgoingConnections, setOutgoingConnections] = useState([]);
  const [incomingConnections, setIncomingConnections] = useState([]);
  const [friends, setFriends] = useState([]); // New state for accepted connections
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchPeople();
    fetchConnections();
  }, []);

  const fetchPeople = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, email')
        .neq('id', user.id)
        .order('username');

      if (error) throw error;
      setPeople(data || []);
    } catch (error) {
      console.error('Error fetching people:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchConnections = async () => {
    try {
      // Outgoing requests (sent by user)
      const { data: outgoingData, error: outgoingError } = await supabase
        .from('career_connections')
        .select('receiver_id, status')
        .eq('requester_id', user.id);

      if (outgoingError) throw outgoingError;
      setOutgoingConnections(outgoingData || []);

      // Incoming requests (received by user, pending)
      const { data: incomingData, error: incomingError } = await supabase
        .from('career_connections')
        .select('requester_id, status')
        .eq('receiver_id', user.id)
        .eq('status', 'pending');

      if (incomingError) throw incomingError;
      setIncomingConnections(incomingData || []);

      // Friends (accepted connections, either direction)
      const { data: friendsData, error: friendsError } = await supabase
        .from('career_connections')
        .select('requester_id, receiver_id')
        .eq('status', 'accepted')
        .or(`requester_id.eq.${user.id},receiver_id.eq.${user.id}`);

      if (friendsError) throw friendsError;
      const friendIds = friendsData.map(conn => 
        conn.requester_id === user.id ? conn.receiver_id : conn.requester_id
      );
      const { data: friendsProfiles, error: friendsProfilesError } = await supabase
        .from('profiles')
        .select('id, username, email')
        .in('id', friendIds);

      if (friendsProfilesError) throw friendsProfilesError;
      setFriends(friendsProfiles || []);
    } catch (error) {
      console.error('Error fetching career_connections:', error);
    }
  };

  const handleConnect = async (targetUserId) => {
    try {
      const { error } = await supabase
        .from('career_connections')
        .insert({
          requester_id: user.id,
          receiver_id: targetUserId,
          status: 'pending',
        });

      if (error) throw error;
      alert('Connection request sent!');
      fetchConnections();
    } catch (error) {
      console.error('Error sending connection request:', error);
      alert('Failed to send connection request.');
    }
  };

  const handleAcceptRequest = async (requesterId) => {
    try {
      const { error } = await supabase
        .from('career_connections')
        .update({ status: 'accepted' })
        .eq('requester_id', requesterId)
        .eq('receiver_id', user.id)
        .eq('status', 'pending');

      if (error) throw error;
      alert('Connection accepted!');
      fetchConnections();
    } catch (error) {
      console.error('Error accepting request:', error);
      alert('Failed to accept connection.');
    }
  };

  const handleRejectRequest = async (requesterId) => {
    try {
      const { error } = await supabase
        .from('career_connections')
        .delete()
        .eq('requester_id', requesterId)
        .eq('receiver_id', user.id)
        .eq('status', 'pending');

      if (error) throw error;
      alert('Connection request rejected!');
      fetchConnections();
    } catch (error) {
      console.error('Error rejecting request:', error);
      alert('Failed to reject connection.');
    }
  };

  const getConnectionStatus = (personId) => {
    const outgoing = outgoingConnections.find(conn => conn.receiver_id === personId);
    if (outgoing) return outgoing.status;
    const isFriend = friends.some(friend => friend.id === personId);
    return isFriend ? 'accepted' : null;
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="flex">
      <Sidebar currentView="people" setView={setView} onLogout={onLogout} />

      <div className="main-content">
        <header className="header">
          <h2><FaUsers className="header-icon" /> Connect with People</h2>
          <div className="user-info">
            <span><FaUser /> {user.email}</span>
          </div>
        </header>

        <div className="people-container">
          {/* My Friends */}
          <div className="friends-section">
            <h1>My Friends</h1>
            {friends.length === 0 ? (
              <p>No friends yet—connect with someone!</p>
            ) : (
              <div className="people-grid">
                {friends.map((friend) => (
                  <div key={friend.id} className="person-card">
                    <img 
                      src="/default-avatar.png" 
                      alt={friend.username} 
                      className="person-avatar"
                    />
                    <h3>{friend.username || 'Unnamed User'}</h3>
                    <p>{friend.email}</p>
                    <div className="person-actions">
                      <button 
                        onClick={() => setView('messages', { selectedUserId: friend.id })}
                        className="message-btn"
                      >
                        <FaEnvelope /> Message
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Incoming Connection Requests */}
          <div className="incoming-requests">
            <h1>Incoming Requests</h1>
            {incomingConnections.length === 0 ? (
              <p>No pending requests</p>
            ) : (
              <div className="people-grid">
                {incomingConnections.map((request) => {
                  const requester = people.find(p => p.id === request.requester_id);
                  return (
                    <div key={request.requester_id} className="person-card">
                      <img 
                        src="/default-avatar.png" 
                        alt="User" 
                        className="person-avatar"
                      />
                      <h3>{requester?.username || 'Unnamed User'}</h3>
                      <p>{requester?.email || 'No email'}</p>
                      <div className="person-actions">
                        <button 
                          onClick={() => handleAcceptRequest(request.requester_id)}
                          className="accept-btn"
                        >
                          <FaCheck /> Accept
                        </button>
                        <button 
                          onClick={() => handleRejectRequest(request.requester_id)}
                          className="reject-btn"
                        >
                          <FaTimes /> Reject
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Discover People */}
          <div className="discover-people">
            <h1>Discover People</h1>
            <div className="people-grid">
              {people.length === 0 ? (
                <p>No users found</p>
              ) : (
                people.map((person) => {
                  const status = getConnectionStatus(person.id);
                  return (
                    <div key={person.id} className="person-card">
                      <img 
                        src="/default-avatar.png" 
                        alt={person.username} 
                        className="person-avatar"
                      />
                      <h3>{person.username || 'Unnamed User'}</h3>
                      <p>{person.email}</p>
                      <div className="person-actions">
                        {!status ? (
                          <button 
                            onClick={() => handleConnect(person.id)}
                            className="connect-btn"
                          >
                            <FaUserPlus /> Connect
                          </button>
                        ) : status === 'pending' ? (
                          <span className="connection-status"><FaHourglassHalf /> Pending</span>
                        ) : status === 'accepted' ? (
                          <span className="connection-status"><FaUserCheck /> Connected</span>
                        ) : null}
                        <button 
                          onClick={() => setView('messages', { selectedUserId: person.id })}
                          className="message-btn"
                        >
                          <FaEnvelope /> Message
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default People;