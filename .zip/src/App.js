import { useState, useEffect } from 'react';
import { supabase } from './supabaseClient';
import Auth from './components/Auth';
import Profile from './components/Profile';
import Jobs from './components/Jobs';
import Courses from './components/Courses';
import Resume from './components/Resume';
import Tasks from './components/Tasks';
import Contests from './components/Contests';
import Interview from './components/Interview';
import Forum from './components/Forum';
import Dashboard from './components/Dashboard';
import People from './components/People';
import Messages from './components/Messages';
import Support from './components/Support';

import FloatingActionButton from './components/FloatingActionButton';
import './global.css';

function App() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState('auth');
  const [viewParams, setViewParams] = useState({});

  useEffect(() => {
    // Check theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      document.documentElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      // If no saved preference, check system preference
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem('theme', 'dark');
    }

    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user ?? null);
      setView(user ? 'dashboard' : 'auth');
    };
    fetchUser();

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      setView(session ? 'dashboard' : 'auth');
    });
    return () => authListener.subscription.unsubscribe();
  }, []);

  const handleSetView = (newView, params = {}) => {
    setView(newView);
    setViewParams(params);
  };

  const components = {
    auth: <Auth />,
    dashboard: <Dashboard user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    profile: <Profile user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    jobs: <Jobs user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    courses: <Courses user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    resume: <Resume user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    tasks: <Tasks user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    contests: <Contests user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    interview: <Interview user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    forum: <Forum user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    people: <People user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    support: <Support 
      user={user} 
      onLogout={() => supabase.auth.signOut()} 
      setView={handleSetView} 
    />,
    messages: <Messages user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} otherUserId={viewParams.selectedUserId} />,
  };

  return (
    <div className={user ? "flex" : "auth-page"}>
      {user ? (
        <>
          {components[view] || <div>Error loading {view} component</div>}
          <FloatingActionButton />
        </>
      ) : (
        <Auth />
      )}
    </div>
  );
}

export default App;