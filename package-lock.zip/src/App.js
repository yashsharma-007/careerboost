import { useState, useEffect } from 'react';
import { supabase } from './supabaseClient';
import Auth from './components/Auth';
import Profile from './components/Profile';
import Jobs from './components/Jobs';
import Courses from './components/Courses';
import Resume from './components/Resume';
import Tasks from './components/Tasks';
import Contests from './components/Contests';
import Interview from './components/Interview';
import Forum from './components/Forum';
import Dashboard from './components/Dashboard';
import People from './components/People';

import Support from './components/Support';

import './global.css';

function App() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState('auth');
  const [viewParams, setViewParams] = useState({});

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user ?? null);
      setView(user ? 'dashboard' : 'auth');
    };
    fetchUser();

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      setView(session ? 'dashboard' : 'auth');
    });
    return () => authListener.subscription.unsubscribe();
  }, []);

  const handleSetView = (newView, params = {}) => {
    setView(newView);
    setViewParams(params);
  };

  const components = {
    auth: <Auth />,
    dashboard: <Dashboard user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    profile: <Profile user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    jobs: <Jobs user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    courses: <Courses user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    resume: <Resume user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    tasks: <Tasks user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    contests: <Contests user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    interview: <Interview user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    forum: <Forum user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    people: <People user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
    support: <Support user={user} onLogout={() => supabase.auth.signOut()} setView={handleSetView} />,
   
  };

  return (
    <div className={user ? "flex" : "auth-page"}>
      {user ? (
        <>
          {components[view]}
          
        </>
      ) : (
        <Auth />
      )}
    </div>
  );
}

export default App;