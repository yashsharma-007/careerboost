import { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { FaEnvelope, FaLock, FaSignInAlt, FaUserPlus, FaRocket, FaChartLine, FaLightbulb, FaBriefcase } from 'react-icons/fa';
import '../auth.css';

const Auth = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [animateCard, setAnimateCard] = useState(false);

  useEffect(() => {
    // Trigger animation when component mounts
    setAnimateCard(true);
  }, []);

  const handleAuth = async (e) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    if (isSignUp) {
      const { data, error } = await supabase.auth.signUp({ email, password });
      setLoading(false);
      if (error) setError(error.message);
      else setMessage('Check your email to confirm your account!');
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) setError(error.message);
      else console.log('User:', data.user);
    }
  };

  const toggleMode = () => {
    setAnimateCard(false);
    setTimeout(() => {
      setIsSignUp(!isSignUp);
      setAnimateCard(true);
    }, 300);
  };

  return (
    <div className="auth-page">
      <div className="auth-background">
        <div className="shape shape-1"></div>
        <div className="shape shape-2"></div>
        <div className="shape shape-3"></div>
        <div className="shape shape-4"></div>
      </div>
      
      <div className="auth-container">
        <div className={`auth-card ${animateCard ? 'animate' : ''}`}>
          <div className="auth-logo">
            <div className="logo-icon">
              <FaRocket />
            </div>
            <h1>CareerBoost</h1>
          </div>
          
          <h2>{isSignUp ? 'Create Account' : 'Welcome Back'}</h2>
          <p>{isSignUp ? 'Join CareerBoost today!' : 'Login to continue your journey'}</p>
          
          <div className="auth-features">
            <div className="feature">
              <FaChartLine />
              <span>Track Progress</span>
            </div>
            <div className="feature">
              <FaLightbulb />
              <span>Get Insights</span>
            </div>
            <div className="feature">
              <FaBriefcase />
              <span>Find Opportunities</span>
            </div>
          </div>
          
          <form className="auth-form" onSubmit={handleAuth}>
            <div className="input-wrapper">
              <FaEnvelope />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <div className="input-highlight"></div>
            </div>
            <div className="input-wrapper">
              <FaLock />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <div className="input-highlight"></div>
            </div>
            
            {!isSignUp && (
              <div className="forgot-password">
                <a href="#">Forgot password?</a>
              </div>
            )}
            
            <button type="submit" disabled={loading} className="auth-button">
              {loading ? (
                <div className="loading-spinner">
                  <div></div><div></div><div></div><div></div>
                </div>
              ) : (
                <>
                  {isSignUp ? <FaUserPlus /> : <FaSignInAlt />} 
                  <span>{isSignUp ? 'Sign Up' : 'Login'}</span>
                </>
              )}
            </button>
          </form>
          
          {error && <p className="auth-error">{error}</p>}
          {message && <p className="auth-message">{message}</p>}
          
          <div className="auth-toggle">
            <p>
              {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
              <button onClick={toggleMode}>
                {isSignUp ? 'Login' : 'Sign Up'}
              </button>
            </p>
          </div>
          
          <div className="auth-footer">
            <p>© {new Date().getFullYear()} CareerBoost. All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth